console.log("insert.js loaded");
//自动弹出记住密码
