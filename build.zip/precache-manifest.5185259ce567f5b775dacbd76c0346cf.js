self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "06b23b7438ca677f8dee4a3ad911577d",
    "url": "/index.html"
  },
  {
    "revision": "86d38c313bf0505bba10",
    "url": "/static/css/content.css"
  },
  {
    "revision": "b2b1eab9e30dda7a9f44",
    "url": "/static/css/main.css"
  },
  {
    "revision": "def79143a856632cd541",
    "url": "/static/js/background.js"
  },
  {
    "revision": "86d38c313bf0505bba10",
    "url": "/static/js/content.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/content.js.LICENSE.txt"
  },
  {
    "revision": "b2b1eab9e30dda7a9f44",
    "url": "/static/js/main.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/main.js.LICENSE.txt"
  },
  {
    "revision": "0ec67e14e00b33dfeb3de1539f4763a1",
    "url": "/static/media/background.0ec67e14.png"
  },
  {
    "revision": "41dddf95fcc3e0e3c75296cdd09b96b8",
    "url": "/static/media/bgg.41dddf95.png"
  },
  {
    "revision": "cef0117ad8ba7696a1f32a00f67ab172",
    "url": "/static/media/btn_bg@2x.cef0117a.png"
  },
  {
    "revision": "049e21edd3b89504d6d1ea5785f28278",
    "url": "/static/media/btn_bg@3x.049e21ed.png"
  },
  {
    "revision": "12b917e19a1ef8defca4a11549822f50",
    "url": "/static/media/createBg.12b917e1.png"
  },
  {
    "revision": "fbf3b95a78535d9920a97d43447d44b9",
    "url": "/static/media/logo.fbf3b95a.png"
  }
]);