self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6cf6ea98b5e12385e4fc41e682420e73",
    "url": "/index.html"
  },
  {
    "revision": "09f79d68a8d876cf0371",
    "url": "/static/css/content.css"
  },
  {
    "revision": "b331265348719dd450c1",
    "url": "/static/css/main.css"
  },
  {
    "revision": "1afd655ccfa7a0813f61",
    "url": "/static/js/background.js"
  },
  {
    "revision": "09f79d68a8d876cf0371",
    "url": "/static/js/content.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/content.js.LICENSE.txt"
  },
  {
    "revision": "b331265348719dd450c1",
    "url": "/static/js/main.js"
  },
  {
    "revision": "f7b6bbc47e40c393226fa77b662cc3c2",
    "url": "/static/js/main.js.LICENSE.txt"
  },
  {
    "revision": "0ec67e14e00b33dfeb3de1539f4763a1",
    "url": "/static/media/background.0ec67e14.png"
  },
  {
    "revision": "41dddf95fcc3e0e3c75296cdd09b96b8",
    "url": "/static/media/bgg.41dddf95.png"
  },
  {
    "revision": "749e5b8517cd36f446a52f4a05f04482",
    "url": "/static/media/btn_add@2x.749e5b85.png"
  },
  {
    "revision": "12b917e19a1ef8defca4a11549822f50",
    "url": "/static/media/createBg.12b917e1.png"
  },
  {
    "revision": "ccd92b2603050b563b0fc4ac4fa9cc60",
    "url": "/static/media/icon_sad.ccd92b26.png"
  },
  {
    "revision": "3c145fec511cad63e059cc22c0d8969b",
    "url": "/static/media/icon_smile.3c145fec.png"
  },
  {
    "revision": "48d374b7fccaf606bef259b7a8363669",
    "url": "/static/media/icon_warning.48d374b7.png"
  },
  {
    "revision": "e6f05ec0f3a533b790392f2af27dbd2f",
    "url": "/static/media/img_02@2x.e6f05ec0.png"
  },
  {
    "revision": "fbf3b95a78535d9920a97d43447d44b9",
    "url": "/static/media/logo.fbf3b95a.png"
  },
  {
    "revision": "09fd27a5d99257b3daef6d8750577126",
    "url": "/static/media/reFreach.09fd27a5.png"
  },
  {
    "revision": "035100c37e802e2d7e4a264001cdd343",
    "url": "/static/media/robot.035100c3.png"
  }
]);