self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9c02a495f4514100de0b4f13c5d43aba",
    "url": "/index.html"
  },
  {
    "revision": "8162bf913f5c66bbf253",
    "url": "/static/css/content.css"
  },
  {
    "revision": "e57c76b2fa2c9be3c17e",
    "url": "/static/css/main.css"
  },
  {
    "revision": "10528d0931f2a15aa1a3",
    "url": "/static/js/background.js"
  },
  {
    "revision": "8162bf913f5c66bbf253",
    "url": "/static/js/content.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/content.js.LICENSE.txt"
  },
  {
    "revision": "e57c76b2fa2c9be3c17e",
    "url": "/static/js/main.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/main.js.LICENSE.txt"
  },
  {
    "revision": "0ec67e14e00b33dfeb3de1539f4763a1",
    "url": "/static/media/background.0ec67e14.png"
  },
  {
    "revision": "41dddf95fcc3e0e3c75296cdd09b96b8",
    "url": "/static/media/bgg.41dddf95.png"
  },
  {
    "revision": "12b917e19a1ef8defca4a11549822f50",
    "url": "/static/media/createBg.12b917e1.png"
  },
  {
    "revision": "ccd92b2603050b563b0fc4ac4fa9cc60",
    "url": "/static/media/icon_sad.ccd92b26.png"
  },
  {
    "revision": "3c145fec511cad63e059cc22c0d8969b",
    "url": "/static/media/icon_smile.3c145fec.png"
  },
  {
    "revision": "48d374b7fccaf606bef259b7a8363669",
    "url": "/static/media/icon_warning.48d374b7.png"
  },
  {
    "revision": "e6f05ec0f3a533b790392f2af27dbd2f",
    "url": "/static/media/img_02@2x.e6f05ec0.png"
  },
  {
    "revision": "fbf3b95a78535d9920a97d43447d44b9",
    "url": "/static/media/logo.fbf3b95a.png"
  },
  {
    "revision": "035100c37e802e2d7e4a264001cdd343",
    "url": "/static/media/robot.035100c3.png"
  }
]);